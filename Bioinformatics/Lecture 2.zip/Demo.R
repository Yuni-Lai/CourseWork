## Welcome to R Programming!
## (All words after # would be taken as annotations in R!!!)
##=========================================================================
## Part1: Introduction
# Set working directory ---------------------------------------------------
#getwd()  ## get the current working directory
#setwd("")  ## set the working directory into the path of the folder where your files locate in

# Get help  ---------------------------------------------------------------
?mean    ## get help of a function named mean
help(mean)
help(package = "ggplot2")   ## get help of a package named ggplot2
##=========================================================================
## Part2: R Grammar
# Install packages  ----------------------------------------------
install.packages("ggplot2") ## install package 'ggplot2' from CRAN

# operation symbol  ---------------------------------------------------------------

# Arithmetic operators:
1 + 2 ## addition
5 - 1 ## subtraction
3 * 5 ## multiplication
10 / 2 ## division
2 ^ 3 ## power
10 %% 2 ## remainder

# Relation operators:
5 > 4 ## greater than
3 < 5 ## less than
3 == 6 ## is equal to
2 <= 8 ## is   less   than   or   equal   to
3 >= 6 ## is   more   than   or   equal   to
5 != 10 ## is   not   equal   to

# logical operators:
(3 > 2) & (6 > 3) ## and
(3 > 2) | (6 < 3) ## or
!(6 < 3) ## not

# assignment operators:
a <- 6 ## recommend
print(a)

b = 5 
print(5)

# Variable ------------------------------------------------------------------

# Assignment using equal operator
Variable1 = c(0,1,2,3)
print(Variable1)

# Assignment using leftward operator
Variable2 = c("learn","R")
print(Variable2)

# Vector ------------------------------------------------------------------
# Creat a vector
apple <- c('red','green','yellow')
print(apple)

# Creat a list
list1 <- list(c(2,5,3),21.3,sin)
print(list1)

# Create a matrix.
M = matrix( c('a','a','b','c','b','a'), nrow = 2, ncol = 3, byrow = TRUE)
print(M)

# Create a factor object.
factor_apple <- factor(apple)
print(factor_apple)

# Create the data frame.
BMI <- 	data.frame(
  gender = c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age = c(42,38,26)
)
print(BMI)

# Example ------------------------------------------------------------------
## RT-qPCR for expression of gene NOLC1 (MYC target) and EFN2B (non-MYC target) 
## in wild type and BPTF-knockdown in a breast cancer cell line MCF-7.
## Each group has five replicates. The ct values were used as example.
## creat vector ct value of NOLC1, EFN2B and GAPDH:
GAPDH <- c(20.01,20.15,19.35,20.57,19.62,19.96,19.01,20.33,20.58,19.93)
print(GAPDH)
NOLC1 <- c(23.93,23.69,24.03,23.67,24.22,20.58,21.02,21.69,22.88,21.74)
print(NOLC1)
EFN2B <- c(21.05,22.33,23.03,22.63,21.98,22.05,22.29,22.07,21.42,21.36)
print(EFN2B)


## creat group label for WT and sh-BPTF
treatment <- rep(c("WT","Sh"), each=5)
print(treatment)

# Subset a vector
NOLC1[5]  ## extract the 5th element of NOLC1
NOLC1[-5]  ## print NOLC1 except for the 5th element
NOLC1[1:5]  ## extract the first 5 elements
NOLC1[-(1:5)] ## print NOLC1 except for the first 5 elements
NOLC1[NOLC1 > 22]  ## return the elements greater than 22
NOLC1[NOLC1 > 21 & NOLC1 < 22]  ## return the elements greater than 21 and less than 22


## Useful operations on vectors
length(NOLC1)  ## return the length of NOLC1
range(NOLC1) ## return the range of values in NOLC1
which.min(NOLC1)  ## return the index of the minimum element in NOLC1
which.max(NOLC1)  ## return the index of the maximum element in NOLC1
sort(NOLC1)  ## sort NOLC1 into ascending order
rev(NOLC1)  ## reverse elements in NOLC1

sum(NOLC1)  ## return the sum of NOLC1
unique(NOLC1)  ## return the unique elements in NOLC1

x <- sample(1:20, 10)
y <- sample(1:20, 15)
union(x, y) ## return the union of x and y(elements either in x or in y)
intersect(x, y)  ## return the intersect of x and y(elements both in x and in y)
setdiff(x, y)   ## return the elements only belongs to x while not belongs to y
identical(x, y)  ## test objects for strict equality


## generate a data frame using data.frame()
ct <- data.frame(
  treatment,
  GAPDH,
  NOLC1,
  EFN2B
)
print(ct)


## Useful operations on data frame
ctValues <- ct[,c("GAPDH","NOLC1","EFN2B")]  ##select three colomns of ct
print(ctValues)

dim(ctValues)   ## return the dimension of ct
ncol(ctValues)   ## return the number of columns of ct
nrow(ctValues)   ## return the number of rows of ct
t(ctValues)   ## transpose ct
rowSums(ctValues)  ## calculate the sum of each row
rowMeans(ctValues)  ## calculate the mean of each row
colSums(ctValues)  ## calculate the sum of each column
colMeans(ctValues)   ## calculate the mean of each column

# read and write data  ----------------------------------------------------

write.csv(ct,file="ct.csv",row.names=F) ## write data frame files into csv
ct_temp <- read.csv("ct.csv") ## read csv files into R
print(ct_temp)

save(ct,file="ct.RData") ## write data frame files into RData
load("ct.RData") ## read RData files into R

write.table(ct, file = "ct.txt", col.names = T, row.names = F, sep = "\t", quote = F)  ## write data frame into txt file
ct_temp <- read.table("ct.txt", header = T, stringsAsFactors = F, sep = "\t")  ## read txt files into R

##=========================================================================
## Part3:Statistical Functions
max(NOLC1)  ## return the maxima
min(NOLC1)  ## return the minima
mean(NOLC1)  ## return the mean
median(NOLC1)  ## return the median
sum(NOLC1)  ## return the sum
sd(NOLC1)  ## return the standard variation
summary(NOLC1) ## return basic statistic results
summary(ctValues) ## return basic statistic results
##=========================================================================
## Part4: Case Study
## RT-qPCR for expression of gene NOLC1 (MYC target) and EFN2B (non-MYC target) 
## in wild type and BPTF-knockdown in a breast cancer cell line MCF-7.
## Each group has five replicates.
## Calculate ????Ct based on ct values from RT-qPCR

## construct ct value data frame
ct <- data.frame(
  treatment = rep(c("WT","Sh"), each=5),
  GAPDH = c(20.01,20.15,19.35,20.57,19.62,19.96,19.01,20.33,20.58,19.93),
  NOLC1 = c(23.93,23.69,24.03,23.67,24.22,20.58,21.02,21.69,22.88,21.74),
  EFN2B = c(21.05,22.33,23.03,22.63,21.98,22.05,22.29,22.07,21.42,21.36)
)
print(ct)

## step 1 calculate mean value of GAPDH in different condition (WT and BPTF-knockdown)
GAPDH_WT_mean <- mean(ct$GAPDH[ct$treatment == "WT"])  ## calue mean ct of GAPDH in wild type group
print(GAPDH_WT_mean)
GAPDH_Sh_mean <- mean(ct$GAPDH[ct$treatment == "Sh"])  ## calue mean ct of GAPDH in knowndown group
print(GAPDH_Sh_mean)

## step 2 calculate ??ct of NOLC1 and EFN2B in WT and Knowndown, respectively
NOLC1_WT <- ct$NOLC1[ct$treatment == "WT"] - GAPDH_WT_mean
NOLC1_SH <- ct$NOLC1[ct$treatment == "Sh"] - GAPDH_Sh_mean
EFN2B_WT <- ct$EFN2B[ct$treatment == "WT"] - GAPDH_WT_mean
EFN2B_SH <- ct$EFN2B[ct$treatment == "Sh"] - GAPDH_Sh_mean
treatment <- rep(c("WT","Sh"), each=5)

delta.ct <- data.frame(  # construct ??ct data frame
  treatment,
  NOLC1 = c(NOLC1_WT,NOLC1_SH),
  EFN2B = c(EFN2B_WT,EFN2B_SH)
)
print(delta.ct)

## step 3 calculate mean value of ??ct of NOLC1 and EFN2B in WT group,respectively
delta.NOLC1_WT_mean <- mean(delta.ct$NOLC1[delta.ct$treatment == "WT"])
delta.EFN2B_WT_mean <- mean(delta.ct$EFN2B[delta.ct$treatment == "WT"])
print(delta.NOLC1_WT_mean)
print(delta.EFN2B_WT_mean)
## step 4 calculate ????ct of NOLC1 and EFN2B in Knowndown, respectively
dd.NOLC1_SH <- delta.ct$NOLC1[delta.ct$treatment == "Sh"] - delta.NOLC1_WT_mean
dd.EFN2B_SH <- delta.ct$EFN2B[delta.ct$treatment == "Sh"] - delta.EFN2B_WT_mean

dd.ct <- data.frame(  # construct ????ct data frame
  NOLC1 = dd.NOLC1_SH,
  EFN2B = dd.EFN2B_SH
)
print(dd.ct)

## step 4 calculate ratio
ratio <- 2^(-1*dd.ct)
print(ratio)
summary(ratio) # return basic statistic results

# compare ratio values of two genes using boxplot  ----------------------------------------------------
boxplot(ratio)

# compare ratio values of two genes using bar plot (beautiful graphics ggplot2)  ----------------------------------------------------
# Install packages if you havn't ----------------------------------------------
#install.packages("ggplot2") ## install package 'ggplot2' from CRAN
library(ggplot2)
NOLC1_mean <- mean(ratio$NOLC1)  # calculate mean value of NOLC1 ratio 
EFN2B_mean <- mean(ratio$EFN2B)  # calculate mean value of EFN2B ratio 

se <- function(x) sqrt(var(x)/length(x)) # define function to calculate standard error(se)

NOLC1_se <- se(ratio$NOLC1)  # calculate se value of NOLC1 ratio 
EFN2B_se <- se(ratio$EFN2B)  # calculate se value of EFN2B ratio 
ratio.stat <- data.frame(gene=c("NOLC1","EFN2B"),
                         mean=c(NOLC1_mean,EFN2B_mean),
                         se=c(NOLC1_se,EFN2B_se))  ## construct data frame
ratio.stat$gene <- factor(ratio.stat$gene, levels = c("NOLC1","EFN2B")) ## set the order of gene in graph
## you can find details for ggplot2 graph using help() or ?ggplot
p <- ggplot(ratio.stat, aes(gene, mean, fill=gene, width=0.5))+geom_bar(stat="identity", position=position_dodge(width=0.6), colour="black")+geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=0.2, position=position_dodge(width=0.8))
p <- p+scale_fill_manual(values=c("#4682B4", "#8B814C"))
p <- p+theme_bw()+theme(legend.position="none") + xlab("")+ylab(expression("Ratio"))
p <- p+theme(axis.text.x=element_text(face="bold", size=12), axis.text.y=element_text(face="bold", size=12), axis.title.y=element_text(size=12, face="bold"))
print(p)

##=========================================================================
# Course End! -------------------------------------------------------------


